import React ,{useState} from 'react'
import './App.css';

const App = () => {
  // console.log(useState('Learn Code With Hafiz in simple way....'));
  // var myval1 = useState('Learning Code with Hafiz')[0];
  // console.log(myval1)


  // var val1 = 'Learn Code With Hafiz';

  const [myName,setMyName] = useState("Haiz")

  const changeName = () =>{
    var val1 = 'Haiz Ammad'
    // console.log(val1);
    setMyName(val1);
  }
  
  console.log(myName);
  return (
    <div>
      <h1>{myName}</h1>
      <button className="btn" onClick={changeName}>Click Me</button>
    </div>
  )
}

export default App