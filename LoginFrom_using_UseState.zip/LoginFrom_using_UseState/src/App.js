import React ,{useState} from 'react'
import './App.css';
// import HooksRule from './component/HooksRule';
import BasicForm from './component/form/BasicForm';
const App = () => {



  return (
      <div>
        <BasicForm/>
      </div>
  )
}



export default App

