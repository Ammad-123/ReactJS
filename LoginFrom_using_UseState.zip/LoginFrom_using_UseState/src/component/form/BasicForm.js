import React, { useState } from 'react'
import './basicForm.css'

const BasicForm = () => {
    const [email, setEamil] = useState("");
    const [password, setPassword] = useState("");
    const [allEntry,setAllEntry]   = useState([]);

    const formSubmit = (e) =>{
        e.preventDefault();
        const newEntry = {email:email,password:password};
        setAllEntry([...allEntry, newEntry]);        
        console.log(allEntry);
    }
  return (
    <>
        <form action='' onSubmit={formSubmit}>
          <div>
            <label htmlFor='email'>Email</label>
            <input type='text' name='email' id='email' autoComplete='off' value={email} onChange={(e) => setEamil(e.target.value)} />
          </div>

          <div>
            <label htmlFor='password'>Password</label>
            <input type='password' name='password' id='password' autoComplete='off' value={password}  onChange={(e) => setPassword(e.target.value) } />
          </div>

          <button type='submit'>Login</button>
        </form>
        <div className='showDetails'>
            {
                allEntry.map((currentElement) => {
                    return (
                        <div className='showDetailsStyle'>
                            <p>{currentElement.email}</p>
                            <p>{currentElement.password}</p>
                        </div>
                    )
                })
            }
        </div>
    </>
  )
}

export default BasicForm