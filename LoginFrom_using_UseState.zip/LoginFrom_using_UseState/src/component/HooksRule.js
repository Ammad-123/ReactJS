// 1- Always write inside the component or function.
// 2- Component name must be in PascalCase (first letter should be Capital)
// 3- we can directly import or we can directly write like this React.hookName. 
// 4- Dont use hooks inside loops , nested functions or conditions.


import React from 'react'

// const hookRule    
const HooksRule = () => {
    const [myName,setMyName] = React.useState('Hafiz');
//    for(i=0; i<=10; i++){
//     const [myName,setMyName] = React.useState('Hafiz');
//    }
//    if(true){
//     const [myName,setMyName] = React.useState('Hafiz');
//    }
  return (
    <h1>{myName}</h1>
  )
}

export default HooksRule